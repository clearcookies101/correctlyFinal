import requests
import json

def test_correction_api():
    url = "http://localhost:8000/correct"
    test_text = "This is a test sentance with some erors and gramar issues."
    
    payload = {
        "text": test_text
    }
    
    try:
        response = requests.post(url, json=payload)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.json()
    except Exception as e:
        print(f"Error: {e}")
        return None

if __name__ == "__main__":
    print("Testing Correctly API...")
    result = test_correction_api()
    if result:
        print("API is working correctly!")
    else:
        print("API test failed.")