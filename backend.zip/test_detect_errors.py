#!/usr/bin/env python3
"""
Test script for the real-time error detection endpoint
"""

import requests
import json

def test_detect_errors():
    """Test the error detection endpoint"""
    url = "http://localhost:8000/detect-errors"
    
    # Test text with intentional errors
    test_cases = [
        {
            "text": "This is a test sentance with some mispelled words.",
            "expected_errors": ["sentance", "mispelled"]
        },
        {
            "text": "The quick brown fox jumps over the lazy dog.",
            "expected_errors": []  # Should be no errors
        },
        {
            "text": "I need to recieve the package tomorow.",
            "expected_errors": ["recieve", "tomorow"]
        }
    ]
    
    for i, test_case in enumerate(test_cases):
        print(f"\n--- Test Case {i+1} ---")
        print(f"Text: {test_case['text']}")
        
        try:
            response = requests.post(url, json={"text": test_case["text"]})
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Status: {response.status_code}")
                print(f"Error count: {result['error_count']}")
                
                if result['errors']:
                    print("Errors found:")
                    for error in result['errors']:
                        print(f"  - '{error['word']}' at position {error['position']}")
                        if error['suggestions']:
                            print(f"    Suggestions: {', '.join(error['suggestions'][:3])}")
                else:
                    print("No errors found")
                    
            else:
                print(f"❌ Error: {response.status_code} - {response.text}")
                
        except Exception as e:
            print(f"❌ Request failed: {e}")

if __name__ == "__main__":
    print("Testing Correctly AI Error Detection API...")
    test_detect_errors()