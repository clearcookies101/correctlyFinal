import requests

test_cases = [
    'Helo world',
    'Recieve the emal', 
    'Thiss is a tset of the sistem',
    'I hav a appl'
]

print('Testing correction API:')
for text in test_cases:
    response = requests.post('http://localhost:8000/correct', json={'text': text})
    result = response.json()
    print(f'Input: {text}')
    print(f'Output: {result["corrected_text"]}')
    print(f'Corrections: {result["corrections_made"]}')
    print('---')