from fastapi import APIRouter, HTTPException
from app.models.correction_models import CorrectionRequest, CorrectionResponse, ErrorDetectionResponse
from app.services.correction_service import process_correction
from app.core.symspell_loader import sym_spell
from symspellpy import Verbosity
from typing import List, Dict
import re

router = APIRouter()

@router.get("/")
def root():
    return {"message": "Correctly API - AI-Powered Autocorrect", "version": "1.0.0", "status": "running"}

@router.post("/correct", response_model=CorrectionResponse)
def correct(request: CorrectionRequest):
    try:
        return process_correction(request.text)
    except Exception as e:
        print(f"[ERROR] {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
def health():
    return {"status": "healthy", "dictionary_loaded": sym_spell.word_count > 0}

@router.post("/detect-errors", response_model=ErrorDetectionResponse)
def detect_errors(request: CorrectionRequest):
    """
    Real-time error detection endpoint that identifies errors in text
    without providing corrections. Returns error positions and suggestions.
    """
    try:
        text = request.text
        words = re.findall(r'\b\w+\b', text.lower())
        errors = []
        
        for i, word in enumerate(words):
            # Check if word is in dictionary
            suggestions = sym_spell.lookup(word, Verbosity.CLOSEST, max_edit_distance=2)
            
            if not suggestions or suggestions[0].term.lower() != word:
                # Find the position of this word in the original text
                word_pattern = r'\b' + re.escape(word) + r'\b'
                for match in re.finditer(word_pattern, text, re.IGNORECASE):
                    errors.append({
                        "word": match.group(),
                        "position": match.start(),
                        "length": len(match.group()),
                        "suggestions": [s.term for s in suggestions[:3]] if suggestions else []
                    })
                    break  # Only take the first occurrence
        
        return {
            "text": text,
            "errors": errors,
            "error_count": len(errors)
        }
    except Exception as e:
        print(f"[ERROR] Error detection failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
