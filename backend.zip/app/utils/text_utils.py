import re
from symspellpy import Verbosity
from app.core.symspell_loader import sym_spell

def correct_word(word: str) -> tuple[str, bool]:
    if len(word) < 2 or not word.isalpha():
        return word, False

    # Convert to lowercase for lookup
    suggestions = sym_spell.lookup(word.lower(), Verbosity.CLOSEST, max_edit_distance=2)

    if suggestions:
        best = suggestions[0].term
        if word.lower() == best.lower():
            return word, False
        # Preserve original capitalization
        if word[0].isupper():
            corrected = best.capitalize()
        elif word.isupper():
            corrected = best.upper()
        else:
            corrected = best
        return corrected, True

    return word, False

def correct_text(text: str) -> tuple[str, int, list]:
    pattern = r'\b\w+\b|[^\w\s]|\s+'
    tokens = re.findall(pattern, text)

    corrected_tokens, details = [], []
    corrections = 0

    for token in tokens:
        if token.strip() and token[0].isalpha():
            corrected, was_corrected = correct_word(token)
            corrected_tokens.append(corrected)
            if was_corrected:
                corrections += 1
                details.append({"original": token, "corrected": corrected})
        else:
            corrected_tokens.append(token)

    return ''.join(corrected_tokens), corrections, details
