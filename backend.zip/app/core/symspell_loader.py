from symspellpy import SymSpell
import pkg_resources

def load_symspell() -> SymSpell:
    sym_spell = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
    dictionary_path = pkg_resources.resource_filename(
        "symspellpy", "frequency_dictionary_en_82_765.txt"
    )
    sym_spell.load_dictionary(dictionary_path, term_index=0, count_index=1)
    return sym_spell

sym_spell = load_symspell()
