import time
from app.utils.text_utils import correct_text
from app.models.correction_models import CorrectionResponse

def process_correction(text: str) -> CorrectionResponse:
    start = time.time()
    if not text.strip():
        return CorrectionResponse(corrected_text="", corrections_made=0, processing_time_ms=0.0, details=[])

    corrected_text, corrections, details = correct_text(text)
    duration = (time.time() - start) * 1000

    print(f"[CORRECTION] Time: {duration:.2f}ms | Corrections: {corrections} | Input length: {len(text)}")

    return CorrectionResponse(
        corrected_text=corrected_text,
        corrections_made=corrections,
        processing_time_ms=round(duration, 2),
        details=details
    )
