from pydantic import BaseModel
from typing import Optional, List

class CorrectionRequest(BaseModel):
    text: str

class CorrectionDetail(BaseModel):
    original: str
    corrected: str

class CorrectionResponse(BaseModel):
    corrected_text: str
    corrections_made: int
    processing_time_ms: float
    details: Optional[List[CorrectionDetail]] = []

class ErrorDetail(BaseModel):
    word: str
    position: int
    length: int
    suggestions: List[str]

class ErrorDetectionResponse(BaseModel):
    text: str
    errors: List[ErrorDetail]
    error_count: int
